/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecometer.EcoMeter;

/**
 *
 * @author joshu
 */
public class EmissionsCalculator {
    //Emission factors for all types
    private static final double ENERGY_FACTOR = 0.23; //0.23kg CO2 per kwh of electricity
    private static final double DIET_FACTOR = 2.5; //2.5kg CO2 per kg of food
    private static final double WASTE_FACTOR = 2.89; //2.89kg CO2 per kg of waste
    //Calculates emissions based on type and amount
    public double calculateEmissions(String type, double amount) {
        switch(type) {
            case "Energy Emissions":
                return amount * ENERGY_FACTOR;
            case "Diet Emissions":
                return amount * DIET_FACTOR;
            case "Waste Emissions":
                return amount * WASTE_FACTOR;
            default:
                return 0.0;
        }
    }
    
    
}
