/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ecometer.EcoMeter;

/**
 *
 * @author Kevin
 */

import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class TransportTrackerGUI_1 extends javax.swing.JFrame {
    private MainMenu mainMenu;
    /**
     * Creates new form TransportTrackerGUI
     */
    public TransportTrackerGUI_1(MainMenu mainMenu) {
        initComponents();
        this.mainMenu = mainMenu; 
        reportBTN.addActionListener(evt -> reportBTNActionPerformed(evt));
    }
    public TransportTrackerGUI_1() {
        initComponents();
        reportBTN.addActionListener(evt -> reportBTNActionPerformed(evt));
    }
  
    private void reportBTNActionPerformed(ActionEvent evt) {
        String carmodel = modelTF.getText();
        String carmake = makeTF.getText();
        String capacity = capacityTF.getText();
        String efficiency = efficiencyTF.getText();
        
        if (carmodel.isEmpty()|| carmake.isEmpty()|| capacity.isEmpty()|| efficiency.isEmpty()){
            JOptionPane.showMessageDialog(this, "Please fill all of the current empty fields", "ERROR MISSING DATA",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        String reportContent = "Vehicle Report\n";
         reportContent += "----------\n";
         reportContent += "Cars\n";
         reportContent += "-------\n";
         reportContent += "Car model:" + carmodel + "\n";
         reportContent += "Car make:" + carmake + "\n";
         reportContent += "Public Transport\n";
         reportContent += "----------";
         reportContent += "Capacity:" + capacity + "\n";
         reportContent += "Electric Vehicle\n";
         reportContent += "----------\n";
         reportContent += "Efficiency:" + efficiency + "\n";
         
         JOptionPane.showMessageDialog(this,
                 reportContent,
                 "Report Generated",
                 JOptionPane.INFORMATION_MESSAGE);
         saveReportToFile(reportContent);
    }
    
    private void saveReportToFile(String reportContent){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("vehicle_report.txt"))){
            writer.write(reportContent);
            JOptionPane.showMessageDialog(this,
                    
                    "Reports been saved to vehicle_report.txt",
                    "Report Done/Saved",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch(IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Problem saving report: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        carsLBL = new javax.swing.JLabel();
        electricvLBL = new javax.swing.JLabel();
        publictransportLBL = new javax.swing.JLabel();
        carmodelLBL = new javax.swing.JLabel();
        carmakeLBL = new javax.swing.JLabel();
        efficiencyLBL = new javax.swing.JLabel();
        capacityLBL = new javax.swing.JLabel();
        modelTF = new javax.swing.JTextField();
        makeTF = new javax.swing.JTextField();
        capacityTF = new javax.swing.JTextField();
        efficiencyTF = new javax.swing.JTextField();
        reportBTN = new javax.swing.JButton();
        backBTN = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        carsLBL.setForeground(new java.awt.Color(0, 153, 153));
        carsLBL.setText("Cars");

        electricvLBL.setForeground(new java.awt.Color(0, 153, 153));
        electricvLBL.setText("Electric Vehicles");

        publictransportLBL.setForeground(new java.awt.Color(0, 153, 153));
        publictransportLBL.setText("Public Transport");

        carmodelLBL.setText("Model :");

        carmakeLBL.setText("Make :");

        efficiencyLBL.setText("Efficency :");

        capacityLBL.setText("Capacity :");

        reportBTN.setBackground(new java.awt.Color(0, 0, 0));
        reportBTN.setForeground(new java.awt.Color(255, 0, 0));
        reportBTN.setText("Generate Report");

        backBTN.setBackground(new java.awt.Color(0, 0, 0));
        backBTN.setForeground(new java.awt.Color(255, 255, 0));
        backBTN.setText("Back To Menu");
        backBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(carsLBL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(publictransportLBL)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(capacityLBL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(capacityTF, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(14, 14, 14))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(efficiencyLBL, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(efficiencyTF, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(carmodelLBL, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                                    .addComponent(carmakeLBL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(makeTF, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(modelTF, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(electricvLBL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 163, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(backBTN)
                            .addComponent(reportBTN))
                        .addGap(29, 29, 29))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carsLBL)
                    .addComponent(publictransportLBL))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carmodelLBL, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(capacityLBL)
                    .addComponent(modelTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(capacityTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(carmakeLBL)
                    .addComponent(makeTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(electricvLBL)
                        .addGap(23, 23, 23))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(reportBTN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(efficiencyLBL)
                    .addComponent(efficiencyTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(backBTN)
                .addGap(31, 31, 31))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBTNActionPerformed
        mainMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backBTNActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new TransportTrackerGUI_1().setVisible(true));
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBTN;
    private javax.swing.JLabel capacityLBL;
    private javax.swing.JTextField capacityTF;
    private javax.swing.JLabel carmakeLBL;
    private javax.swing.JLabel carmodelLBL;
    private javax.swing.JLabel carsLBL;
    private javax.swing.JLabel efficiencyLBL;
    private javax.swing.JTextField efficiencyTF;
    private javax.swing.JLabel electricvLBL;
    private javax.swing.JTextField makeTF;
    private javax.swing.JTextField modelTF;
    private javax.swing.JLabel publictransportLBL;
    private javax.swing.JButton reportBTN;
    // End of variables declaration//GEN-END:variables
}